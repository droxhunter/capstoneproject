/api/bookings/
/api/registration/
